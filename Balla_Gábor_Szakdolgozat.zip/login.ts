  login(data: LoginData): Observable<any> {
    return this.getCsrfCookie().pipe(
      switchMap(() => {
        return this.http
          .post<any>(`${environment.apiUrl}/auth/login`, data, {
            withCredentials: true,
          })
          .pipe(tap((res) => this.handleAuthResponse(res)));
      }),
    );
  }